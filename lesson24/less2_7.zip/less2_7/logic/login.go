package logic

import "fmt"

func main() {

	fmt.Println("逻辑处理")
}
